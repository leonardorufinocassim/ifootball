package br.com.leonardoeigor.ifootball.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.leonardoeigor.ifootball.model.Evento;
import br.com.leonardoeigor.ifootball.repository.EventoRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class EventoService{
    private final Logger log = LoggerFactory.getLogger(EventoService.class);
    
    @Autowired
    EventoRepository eventoRepository;

    public Evento save(Evento evento) {
        evento = eventoRepository.save(evento);
        return evento;
    }

    public Optional<Evento> findOne(Long idEvento){
        log.info("Request to get evento : {}", idEvento);
        return eventoRepository.findById(idEvento);
    }

    public List<Evento> findAllList(){
        log.info("Request to get All eventos");
        List<Evento> eventoList = eventoRepository.findAll();
        log.info("Return of getAllList " + eventoList.size());
        return eventoList;
    }

    public void delete(Long idEvento){
        log.info("Request to delete evento : {}", idEvento);
        eventoRepository.deleteById(idEvento);
    }

    public List<Evento> saveAll(List<Evento> eventoList){
        log.info("Request to save evento : {}", eventoList);
        eventoList = eventoRepository.saveAll(eventoList);
        return eventoList;
    }
}

    