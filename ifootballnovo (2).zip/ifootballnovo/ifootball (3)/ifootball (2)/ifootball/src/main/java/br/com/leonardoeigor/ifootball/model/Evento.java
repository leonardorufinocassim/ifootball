package br.com.leonardoeigor.ifootball.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Entity (name = "evento")

public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idEvento;

    @Column(length = 60, nullable = false)
    private String dataeve;

    @Column(length = 60, nullable = false)
    private String horario;

    @Column(length = 60, nullable = false)
    private String local;

    @Column(length = 60, nullable = false)
    private String valortotal;

    @Column(length = 60, nullable = false)
    private String situacao;

    @Column(length = 60, nullable = false)
    private String descricao;

    @Column(length = 60, nullable = false)
    private String idUsuario;

   

    public Evento(String dataeve, String horario, String local, String valortotal,String situacao,String descricao,String idUsuario ){
        this.dataeve = dataeve;
        this.horario = horario;
        this.local = local;
        this.valortotal = valortotal;
        this.situacao = situacao;
        this.descricao = descricao;
        this.idUsuario = idUsuario;
    }

    public Object getId() {
        return null;
    } 
    
}
