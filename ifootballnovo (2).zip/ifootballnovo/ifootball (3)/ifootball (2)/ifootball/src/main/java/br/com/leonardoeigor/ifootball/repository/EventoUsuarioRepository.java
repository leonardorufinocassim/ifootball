package br.com.leonardoeigor.ifootball.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import br.com.leonardoeigor.ifootball.model.EventoUsuario;

@Repository
public interface EventoUsuarioRepository extends JpaRepository<EventoUsuario, Long> {
    
}
