package br.com.leonardoeigor.ifootball;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.com.leonardoeigor.ifootball.model.Evento;
import br.com.leonardoeigor.ifootball.model.EventoUsuario;
import br.com.leonardoeigor.ifootball.model.Usuario;
import br.com.leonardoeigor.ifootball.repository.EventoRepository;
import br.com.leonardoeigor.ifootball.repository.EventoUsuarioRepository;
import br.com.leonardoeigor.ifootball.repository.UsuarioRepository;
import br.com.leonardoeigor.ifootball.service.UsuarioService;
import br.com.leonardoeigor.ifootball.service.EventoService;
import br.com.leonardoeigor.ifootball.service.EventoUsuarioService;

@SpringBootApplication
public class ifootballApplication implements ApplicationRunner{

	@Autowired
	UsuarioRepository UsuarioRepository;

	@Autowired
	EventoUsuarioRepository EventoUsuarioRepository;

	@Autowired
	EventoRepository EventoRepository;

	@Autowired
	UsuarioService UsuarioService;

	@Autowired
	EventoService EventoService;
	
	@Autowired
	EventoUsuarioService EventoUsuarioService;

	public static void main(String[] args) {
		SpringApplication.run(ifootballApplication.class, args);
	}

	@Override
	public void run(ApplicationArguments args){
	    Usuario usuario1 = new Usuario("Neymar","neymar@gmail.com","123");
		usuario1 = UsuarioRepository.save(usuario1);
		System.out.println(usuario1);

	   Evento evento1 = new Evento("12/02/2021","13:00","Alvorada","15","Confirmado","Ao lado","1" );
		evento1 = EventoRepository.save(evento1);
		System.out.println(evento1);

		EventoUsuario eventouser1 = new EventoUsuario("12","sim","100","1", "1" );
		eventouser1 = EventoUsuarioRepository.save(eventouser1);
		System.out.println(eventouser1);
		
 }
}
    