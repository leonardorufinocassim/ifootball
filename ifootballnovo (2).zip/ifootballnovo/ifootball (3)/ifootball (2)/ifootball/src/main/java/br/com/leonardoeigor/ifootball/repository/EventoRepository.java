package br.com.leonardoeigor.ifootball.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import br.com.leonardoeigor.ifootball.model.Evento;

@Repository
public interface EventoRepository extends JpaRepository<Evento, Long> {
    
}
