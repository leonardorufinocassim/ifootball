package br.com.leonardoeigor.ifootball;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IfootballApplicationTests {

	@Test
	void contextLoads() {
	}

}
