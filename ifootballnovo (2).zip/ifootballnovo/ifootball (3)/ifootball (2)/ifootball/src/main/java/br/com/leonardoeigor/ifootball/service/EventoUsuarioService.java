package br.com.leonardoeigor.ifootball.service;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;

import br.com.leonardoeigor.ifootball.model.EventoUsuario;
import br.com.leonardoeigor.ifootball.repository.EventoUsuarioRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class EventoUsuarioService{
    private final Logger log = LoggerFactory.getLogger(EventoUsuarioService.class);
    
    @Autowired
    EventoUsuarioRepository eventousuarioRepository;

    public EventoUsuario save(EventoUsuario eventousuario) {
        eventousuario = eventousuarioRepository.save(eventousuario);
        return eventousuario;
    }

    public Optional<EventoUsuario> findOne(Long idOrgTimes){
        log.info("Request to get eventousuario : {}", idOrgTimes);
        return eventousuarioRepository.findById(idOrgTimes);
    }

    public List<EventoUsuario> findAllList(){
        log.info("Request to get All eventousuarios");
        List<EventoUsuario> eventousuarioList = eventousuarioRepository.findAll();
        log.info("Return of getAllList " + eventousuarioList.size());
        return eventousuarioList;
    }

    public void delete(Long idOrgTimes){
        log.info("Request to delete eventousuario : {}", idOrgTimes);
        eventousuarioRepository.deleteById(idOrgTimes);
    }

    public List<EventoUsuario> saveAll(List<EventoUsuario> eventousuarioList){
        log.info("Request to save eventousuario : {}", eventousuarioList);
        eventousuarioList = eventousuarioRepository.saveAll(eventousuarioList);
        return eventousuarioList;
    }
}

    