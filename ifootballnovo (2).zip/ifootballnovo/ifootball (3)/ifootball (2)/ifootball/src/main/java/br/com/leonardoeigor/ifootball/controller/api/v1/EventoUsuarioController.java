package br.com.leonardoeigor.ifootball.controller.api.v1;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.server.ResponseStatusException;

import br.com.leonardoeigor.ifootball.model.EventoUsuario;
import br.com.leonardoeigor.ifootball.service.EventoUsuarioService;

@Controller
@RequestMapping("api/v1/eventousuario")

public class EventoUsuarioController{
    
    private static EventoUsuarioService EventoUsuarioService;

    @Autowired
    public EventoUsuarioController(EventoUsuarioService EventoUsuarioService){
        EventoUsuarioController.EventoUsuarioService = EventoUsuarioService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<EventoUsuario> getEventoUsuario(@PathVariable Long id){
        Optional<EventoUsuario> EventoUsuarioOp = EventoUsuarioService.findOne(id);
        if(EventoUsuarioOp.isPresent()){
            return ResponseEntity.ok().body(EventoUsuarioOp.get());
        }else{
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<EventoUsuario>> getEventoUsuarios(){
        List<EventoUsuario> EventoUsuarioList = EventoUsuarioService.findAllList();
        if(EventoUsuarioList.size() > 0){
            return ResponseEntity.ok().body(EventoUsuarioList);
        }else{
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/")
    public ResponseEntity<EventoUsuario> update(@RequestBody EventoUsuario EventoUsuario){
        if(EventoUsuario.getId() == null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid EventoUsuario id = null");
        }
        EventoUsuario = EventoUsuarioService.save(EventoUsuario);
        return ResponseEntity.ok().body(EventoUsuario);
    }

    @PostMapping("/")
    public ResponseEntity<EventoUsuario> create(@RequestBody EventoUsuario EventoUsuario){
        if(EventoUsuario.getId() != null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "New EventoUsuario can't exists id.");
        }
        return ResponseEntity.ok().body(EventoUsuario);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEventoUsuario(@PathVariable Long id){
        EventoUsuarioService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
    