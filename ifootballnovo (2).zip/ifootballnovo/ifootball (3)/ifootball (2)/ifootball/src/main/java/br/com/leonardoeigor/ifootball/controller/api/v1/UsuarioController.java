package br.com.leonardoeigor.ifootball.controller.api.v1;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.server.ResponseStatusException;

import br.com.leonardoeigor.ifootball.model.Usuario;
import br.com.leonardoeigor.ifootball.service.UsuarioService;

@Controller
@RequestMapping("api/v1/usuario")

public class UsuarioController{
    
    private static UsuarioService UsuarioService;

    @Autowired

    public UsuarioController(UsuarioService UsuarioService){
        UsuarioController.UsuarioService = UsuarioService;
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuario> getUsuario(@PathVariable Long id){
        Optional<Usuario> UsuarioOp = UsuarioService.findOne(id);
        if(UsuarioOp.isPresent()){
            return ResponseEntity.ok().body(UsuarioOp.get());
        }else{
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/")
    public ResponseEntity<List<Usuario>> getUsuarios(){
        List<Usuario> UsuarioList = UsuarioService.findAllList();
        if(UsuarioList.size() > 0){
            return ResponseEntity.ok().body(UsuarioList);
        }else{
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/")
    public ResponseEntity<Usuario> update(@RequestBody Usuario Usuario){
        if(Usuario.getId() == null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Invalid Usuario id = null");
        }
        Usuario = UsuarioService.save(Usuario);
        return ResponseEntity.ok().body(Usuario);
    }

    @PostMapping("/")
    public ResponseEntity<Usuario> create(@RequestBody Usuario Usuario){
        if(Usuario.getId() != null){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "New Usuario can't exists id.");
        }
        return ResponseEntity.ok().body(Usuario);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUsuario(@PathVariable Long id){
        UsuarioService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
    